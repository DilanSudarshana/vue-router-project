<?php
defined('BASEPATH') or exit('No direct script access allowed');

class AttendanceModel extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function get_attendance_details(){
        return $this->db->get('attendance')->result();
    }

    public function get_attendace_by_id($data){
        return $this->db->where('user_id',$data['user_id'])
        ->where('mark_date',$data['mark_date'])
        ->get('attendance')->row();
    }

    public function check_avalability($data){
        $this->db->select('*');
        $this->db->from('attendance');
        $this->db->where('user_id',$data['user_id']);
        $this->db->where('mark_date',$data['mark_date']);
        $result = $this->db->get()->result();

        if (count($result) > 0) {
            return true;  
        } else {
            return false;
        }
    }

    public function create_new_attendance($data){
        return $this->db->insert('attendance',$data);
    }

    public function mark_check_out($id,$data){

        $this->db->select('*');
        $this->db->where('user_id',$id);
        $this->db->where('attendace_status',1);
        $result=$this->db->get('attendance')->result();

        if (count($result) > 0) {
            $this->db->where('user_id',$id);
            $this->db->where('attendace_status',1);
            return $this->db->update('attendance', $data);
        } else {
            return false;
        }
    }

}
