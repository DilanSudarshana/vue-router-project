<?php
defined('BASEPATH') or exit('No direct script access allowed');

class SummaryModel extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function get_summary(){
        $this->db->select('attendance.*, users.first_name, users.last_name');
        $this->db->from('attendance');
        $this->db->join('users', 'users.id = attendance.user_id', 'left');
        $this->db->order_by('attendance.id', 'DESC');
        $query = $this->db->get();
        return $query->result();
    }

    public function filter_data($data){
        $this->db->select('*');
        $this->db->from('attendance');
        $this->db->where('user_id',$data['user_id']);
        $this->db->where('mark_date >=',$data['start_date']);
        $this->db->where('mark_date <=',$data['end_date']);
        return $this->db->get()->result();
    }

}
