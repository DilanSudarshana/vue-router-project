<?php
defined('BASEPATH') or exit('No direct script access allowed');

class UserModel extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function get_user()
    {

        $this->db->select('users.*, emp_type.type_name'); 
        $this->db->from('users');
        $this->db->join('emp_type', 'emp_type.id =users.employee_type');
        $query = $this->db->get();
        return $query->result();
    }

    public function find_user($id){

        $this->db->where('id',$id);
        $query=$this->db->get('users');
        return $query->row();
    }

    public function insert_user($data){

        return $this->db->insert('users',$data);
    }

    public function update_user($id,$data){
        return $this->db->where('id', $id)->update('users', $data);
    }

    public function delete_user($id){ 
        return $this->db->where('id', $id)->delete('users');
    }
}
