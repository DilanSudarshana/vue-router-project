<?php
defined('BASEPATH') or exit('No direct script access allowed');

class EmployeeTypeModel extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function get_employee_type(){
        $query=$this->db->get('emp_type');
        return $query->result();
    }

    public function find_employee_type( $id ){
        $this->db->where('id',$id);
        $query=$this->db->get('emp_type');
        return $query->row();
    }
    
    public function insert_new_employee_type($data){
        return $this->db->insert('emp_type',$data);
    }

}
