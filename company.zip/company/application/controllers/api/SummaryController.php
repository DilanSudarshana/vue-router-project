<?php
defined('BASEPATH') or exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class SummaryController extends REST_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->model('api/SummaryModel');
        $this->load->helper('url');
        $this->load->library('session');
    }

    /**
     * GET: Fetch all users
     *
     * @return JSON response with all users
     */

    public function index_get(){
        
        $summary=new SummaryModel;
        $result=$summary->get_summary();
        $this->response( $result,200);
    }

    public function filter_get(){


        $summary = new SummaryModel;
        $json_data = json_decode($this->input->raw_input_stream, true);
    
        $data = [];

        $user_id = $this->input->get('user_id');
        $start_date = $this->input->get('start_date');
        $end_date = $this->input->get('end_date');

        if (!empty($user_id)) {
            $data['user_id'] = $user_id;
        }
        if (!empty($start_date)) {
            $data['start_date'] = $start_date;
        }
        if (!empty($end_date)) {
            $data['end_date'] = $end_date;
        }

        $result=$summary->filter_data($data);

        if ( $result) {
            $this->response([
                'status' => true,
                'message' => 'Data found successfully.',
                'data'=> $result
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'Failed to find data.'
            ], REST_Controller::HTTP_OK);
        }
    }

}
