<?php
defined('BASEPATH') or exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class AttendanceController extends REST_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->model('api/AttendanceModel');
        $this->load->helper('url');
    }

    /**
     * GET: Fetch all attendace
     *
     * @return JSON response with all attendance details
     */

    public function index_get(){

        $attendance=new AttendanceModel;
        $result=$attendance->get_attendance_details();
        $this->response($result,200);

    }

     /**
     * GET: get attendace by user id
     * @param int $id user id
     * @return JSON response with user details
     */
    
    public function find_get($id){
       
        $attendance=new AttendanceModel;

        $data=[
            'user_id'=>$id,
            'mark_date'=>date("Y-m-d"),
        ];

        $result=$attendance->get_attendace_by_id($data);
       
        if ( $result) {
            $this->response([
                'status' => true,
                'message' => 'Attendance find successfully.',
                'data'=> $result
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'Failed to find attendance.'
            ], REST_Controller::HTTP_OK);
        }
    }

     /**
     * POST: create new attendace
     * 
     * @return JSON response with success or fail
     */

    public function index_post(){

        $attendance=new AttendanceModel;

        $data=[
            'user_id'=>$this->input->post('user_id'),
        ];
        
        $data_avalability=[
            'user_id'=>$this->input->post('user_id'),
            'mark_date'=>date("Y-m-d"),
        ];

        $check_avalability_result=$attendance->check_avalability($data_avalability);

        if ($check_avalability_result) {

            $this->response([
            'status'=>false,
            'message'=>'Cant create attendance for today already created.'],
            REST_Controller::HTTP_OK);

        }else{

            $result=$attendance->create_new_attendance($data);
            if( $result){
                $this->response([
                    'status'=>true,
                    'message'=>'Attendance created successfully'
                ],REST_Controller::HTTP_OK);
            }else{
                $this->response([
                    'status'=>false,
                    'message'=>'Failed to create attendance'
                ],REST_Controller::HTTP_OK);
            }
        } 
    }

    /**
     * PUT: Update attendance with user id
     * @param int $id user id
     * @return JSON response with success or fail
     */

    public function index_put($id) {

        $this->response($id);
        $attendance=new AttendanceModel;
    
        $data = [];
        $data['check_out']=date("Y-m-d H:i:s");
        $data['attendace_status'] = 2;
    
        $chek_out_result = !empty($data) ? $attendance->mark_check_out($id, $data) : true;
        
        if ( $chek_out_result) {
            $this->response([
                'status' => true,
                'message' => 'User check out successfully.'
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'Failed check out attendance.'
            ], REST_Controller::HTTP_OK);
        }
        
    }

     /**
     * DELETE: Delete user with user id
     * @param int $id user id
     * @return JSON response with success or fail
     */

    public function index_delete($id){

        
    }
    
                        
}
