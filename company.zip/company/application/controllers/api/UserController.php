<?php
defined('BASEPATH') or exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class UserController extends REST_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->model('api/UserModel');
        $this->load->helper('url');
    }

    /**
     * GET: Fetch all users
     *
     * @return JSON response with all users
     */

    public function index_get(){
        $user=new UserModel;
        $result=$user->get_user();
        $this->response($result,200);
    }

     /**
     * GET: Find user by user id
     * @param int $id user id
     * @return JSON response with user details
     */
    
    public function find_get($id){
        $user=new UserModel;
        $result=$user->find_user($id);
        $this->response($result,200);
    }

     /**
     * POST: create new user
     * 
     * @return JSON response with success or fail
     */

    public function index_post(){

        $user=new UserModel;
        $json_data = json_decode($this->input->raw_input_stream, true);

        $data=[
            'first_name'=>$this->input->post('first_name'),
            'last_name'=>$this->input->post('last_name'),
            'dob'=>$this->input->post('dob'),
            'gender'=>$this->input->post('gender'),
            'email'=>$this->input->post('email'),
            'address'=>$this->input->post('address'),
            'employee_type'=>$this->input->post('employee_type'),
            'description'=>$this->input->post('description'),
            'phone_number'=>$this->input->post('phone_number'),
        ];

        $result=$user->insert_user($data);

        if( $result){
            $this->response([
                'status'=>true,
                'message'=>'Staff Created Sucessfull'
            ],REST_Controller::HTTP_OK);
        }else{
            $this->response([
                'status'=>false,
                'message'=>'Failed to create staff'
            ],REST_Controller::HTTP_OK);
        }
    }

    /**
     * PUT: Update user with user id
     * @param int $id user id
     * @return JSON response with success or fail
     */

    public function index_put($id) {

        $user = new UserModel;
        $json_data = json_decode($this->input->raw_input_stream, true);
    
        $data = [];

        if (!empty($json_data['first_name'])) {
            $data['first_name'] = $json_data['first_name'];
        }
        if (!empty($json_data['last_name'])) {
            $data['last_name'] = $json_data['last_name'];
        }
    
        if (!empty($json_data['dob'])) {
            $data['dob'] = $json_data['dob'];
        }
        if (!empty($json_data['gender'])) {
            $data['gender'] = $json_data['gender'];
        }
        if (!empty($json_data['email'])) {
            $data['email'] = $json_data['email'];
        }
        if (!empty($json_data['address'])) {
            $data['address'] = $json_data['address'];
        }
        if (!empty($json_data['employee_type'])) {
            $data['employee_type'] = $json_data['employee_type'];
        }
        if (!empty($json_data['description'])) {
            $data['description'] = $json_data['description'];
        }
        if (!empty($json_data['phone_number'])) {
            $data['phone_number'] = $json_data['phone_number'];
        }
    
        $updated_result = !empty($data) ? $user->update_user($id, $data) : true;
        
        if ( $updated_result) {
            $this->response([
                'status' => true,
                'message' => 'User updated successfully.'
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'Failed to update user.'
            ], REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

     /**
     * DELETE: Delete user with user id
     * @param int $id user id
     * @return JSON response with success or fail
     */

    public function index_delete($id){

        echo($id);
        $user = new UserModel;
        $result=$user->delete_user($id);

        if ( $result) {
            $this->response([
                'status' => true,
                'message' => 'User deleted successfully.'
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'Failed to delete user.'
            ], REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    
                        
}
