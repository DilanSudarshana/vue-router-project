<?php
defined('BASEPATH') or exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class EmployeeTypeController extends REST_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->model('api/EmployeeTypeModel');
        $this->load->helper('url');
        $this->load->library('session');
    }

    /**
     * GET: Fetch all users
     *
     * @return JSON response with all users
     */

     public function index_get(){
        
        $emp_type=new EmployeeTypeModel;
        $result=$emp_type->get_employee_type();
        $this->response( $result,200);
    }

     /**
     * GET: Find user by user id
     * @param int $id user id
     * @return JSON response with user details
     */
    
    public function find_get($id){

        $emp_type=new EmployeeTypeModel;
        $result=$emp_type->find_employee_type($id);
        $this->response($result,200);
    }

    public function index_post(){

        $emp_type=new EmployeeTypeModel;

        $data=[
            'type_name'=>$this->input->post('type_name'),
            'description'=>$this->input->post('description'),
        ];

        $result=$emp_type->insert_new_employee_type($data);
        if( $result){
            $this->response([
                'status'=>true,
                'message'=>'Type Inserted Sucessfull'
            ],REST_Controller::HTTP_OK);
        }else{
            $this->response([
                'status'=>false,
                'message'=>'Type Inserted Failed'
            ],REST_Controller::HTTP_OK);
        }
    }
}
