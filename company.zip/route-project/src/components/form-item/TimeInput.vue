<template>
    <div class="col-lg-6 col-md-6 mb-1">
        <p class="text-muted fs-6 ms-1">Time</p>
        <input type="time" class="form-control" />
    </div>
</template>
<script>
export default {
    name: 'TimeInput',

}
</script>
<style></style>