<template>
    <div class="col-lg-6 col-md-6 mb-1">
        <p class="text-muted fs-6 ms-1">Date</p>
        <input type="date" class="form-control"/>
    </div>
</template>
<script>
export default {
    name: 'DateInput',

}
</script>
<style></style>