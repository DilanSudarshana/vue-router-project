<template>
    <div class="col-lg-12 text-white text-center p-3" style="background-color:#2b2d42;">
        <div class="d-flex justify-content-between">
            <div>
                <span><i class="bi bi-building-fill"></i></span>
                <span class="fw-bold ms-2">Employee Managemets stystem</span>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    name: 'Header',
}
</script>
