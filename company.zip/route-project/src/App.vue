<template>
    <Layout></Layout>
</template>

<script>
import Layout from './Layout.vue';
export default {
  name: 'App',

  components:{
    Layout,
  }
}
</script>